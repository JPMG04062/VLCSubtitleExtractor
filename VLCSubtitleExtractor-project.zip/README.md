# VLC Subtitle Extractor

Aplicação Android experimental para localizar ficheiros de legendas na pasta privada de ficheiros do VLC e copiá-los para Downloads.

## Requisitos
- Android 8.0 ou superior.
- VLC para Android.
- Shizuku instalado e iniciado por depuração sem fios.
- Autorizar o acesso Shizuku à aplicação.

## Compilar
O projeto usa Android Gradle Plugin 8.7.3 e Gradle 8.9. O workflow do GitHub Actions pode compilar o APK de depuração.

## Nota
Esta versão procura em `/sdcard/Android/data/org.videolan.vlc/files`. A localização real pode variar com a versão do VLC. É uma primeira versão experimental e precisa de ser compilada e testada no dispositivo antes de ser considerada funcional.
