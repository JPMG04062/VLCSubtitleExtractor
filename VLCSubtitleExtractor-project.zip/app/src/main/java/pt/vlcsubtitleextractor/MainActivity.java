package pt.vlcsubtitleextractor;

import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.view.Gravity;
import android.widget.*;
import java.io.*;
import java.util.*;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 4102;
    private static final String VLC_DIR = "/sdcard/Android/data/org.videolan.vlc/files";
    private LinearLayout results;
    private EditText search;
    private TextView status;
    private final List<String> files = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        status.setText(Shizuku.pingBinder() ? "Shizuku ativo. Autoriza o acesso e procura as legendas." : "Abre o Shizuku e inicia-o através da depuração sem fios.");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 32, 24, 24);
        scroll.addView(root);
        TextView title = new TextView(this);
        title.setText("VLC Subtitle Extractor");
        title.setTextSize(24);
        title.setPadding(0,0,0,12);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("Procura legendas guardadas pelo VLC e copia-as para a pasta Downloads.");
        info.setTextSize(16);
        root.addView(info);
        Button permission = new Button(this);
        permission.setText("1 — Autorizar acesso Shizuku");
        permission.setOnClickListener(v -> requestShizuku());
        root.addView(permission);
        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Filtrar por filme ou episódio");
        root.addView(search);
        Button scan = new Button(this);
        scan.setText("2 — Procurar legendas");
        scan.setOnClickListener(v -> scanFiles());
        root.addView(scan);
        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0,16,0,16);
        root.addView(status);
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);
        setContentView(scroll);
        search.setOnEditorActionListener((v, action, event) -> { showResults(); return false; });
    }

    private void requestShizuku() {
        if (!Shizuku.pingBinder()) {
            status.setText("Shizuku não está ativo. Inicia-o primeiro na aplicação Shizuku.");
        } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            status.setText("Permissão Shizuku já concedida. Podes procurar.");
        } else {
            Shizuku.requestPermission(REQUEST_CODE);
            status.setText("Confirma a autorização na janela do Shizuku e volta aqui.");
        }
    }

    private Process shell(String command) throws Exception {
        return Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
    }

    private void scanFiles() {
        if (!Shizuku.pingBinder()) { status.setText("Shizuku não está ativo."); return; }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            status.setText("Autoriza primeiro o acesso Shizuku.");
            requestShizuku();
            return;
        }
        status.setText("A procurar…");
        new Thread(() -> {
            List<String> found = new ArrayList<>();
            try {
                String cmd = "find '" + VLC_DIR + "' -type f \\( -iname '*.srt' -o -iname '*.sub' -o -iname '*.ass' -o -iname '*.ssa' \\) 2>/dev/null";
                Process p = shell(cmd);
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;
                while ((line = br.readLine()) != null) found.add(line);
                p.waitFor();
                runOnUiThread(() -> {
                    files.clear(); files.addAll(found); showResults();
                    status.setText(found.isEmpty() ? "Não foram encontradas legendas. Confirma se o VLC já descarregou alguma e se a pasta existe." : found.size() + " ficheiro(s) encontrado(s).");
                });
            } catch (Exception e) { runOnUiThread(() -> status.setText("Erro: " + e.getMessage())); }
        }).start();
    }

    private void showResults() {
        results.removeAllViews();
        String q = search.getText().toString().toLowerCase(Locale.ROOT).trim();
        for (String path : files) {
            String name = path.substring(path.lastIndexOf('/') + 1);
            if (!q.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(q)) continue;
            Button item = new Button(this);
            item.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            item.setText(name + "\nCopiar para Downloads");
            item.setOnClickListener(v -> copyFile(path, name));
            results.addView(item);
        }
    }

    private String quote(String s) { return "'" + s.replace("'", "'\\''") + "'"; }

    private void copyFile(String source, String name) {
        String safeName = name.replaceAll("[^A-Za-z0-9._ -]", "_");
        String destination = "/sdcard/Download/" + safeName;
        status.setText("A copiar " + name + "…");
        new Thread(() -> {
            try {
                Process p = shell("mkdir -p /sdcard/Download && cp " + quote(source) + " " + quote(destination));
                BufferedReader err = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                StringBuilder error = new StringBuilder(); String line;
                while ((line = err.readLine()) != null) error.append(line).append("\n");
                int code = p.waitFor();
                runOnUiThread(() -> status.setText(code == 0 ? "Copiada para Downloads: " + safeName : "Falha ao copiar: " + error));
            } catch (Exception e) { runOnUiThread(() -> status.setText("Erro: " + e.getMessage())); }
        }).start();
    }
}
