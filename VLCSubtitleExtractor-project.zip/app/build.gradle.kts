plugins { id("com.android.application") }
android {
    namespace = "pt.vlcsubtitleextractor"
    compileSdk = 35
    defaultConfig {
        applicationId = "pt.vlcsubtitleextractor"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
