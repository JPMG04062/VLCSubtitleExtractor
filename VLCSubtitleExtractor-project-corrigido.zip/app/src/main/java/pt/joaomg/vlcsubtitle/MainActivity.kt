package pt.joaomg.vlcsubtitle

import android.content.ComponentName
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private var remote by mutableStateOf<ISubtitleService?>(null)
    private var status by mutableStateOf("A aguardar ligação ao Shizuku")
    private var subtitles by mutableStateOf<List<String>>(emptyList())
    private var query by mutableStateOf("")
    private val root = "/storage/emulated/0/Android/data/org.videolan.vlc/files"
    private val permissionRequest = 4102

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == permissionRequest && grantResult == PackageManager.PERMISSION_GRANTED) connectService()
        else status = "Acesso Shizuku não autorizado."
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remote = ISubtitleService.Stub.asInterface(service)
            status = "Ligado. Podes procurar legendas."
            refresh()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null; status = "Ligação ao Shizuku interrompida."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("VLC Subtitle Extractor", style = MaterialTheme.typography.headlineSmall)
                        Text("Procura ficheiros .srt guardados pelo VLC e copia-os para Downloads.")
                        Text(status, style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { startAccess() }) { Text("Ligar ao Shizuku") }
                            OutlinedButton(onClick = { refresh() }, enabled = remote != null) { Text("Atualizar") }
                        }
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Pesquisar filme ou episódio") }, singleLine = true)
                        Text("${filtered().size} legenda(s) encontrada(s)")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(filtered(), key = { it }) { path ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(path.substringAfterLast('/'), style = MaterialTheme.typography.titleMedium)
                                        Text(path.substringBeforeLast('/'), style = MaterialTheme.typography.bodySmall)
                                        TextButton(onClick = { copy(path) }) { Text("Copiar para Downloads") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun filtered() = subtitles.filter { it.substringAfterLast('/').contains(query, ignoreCase = true) }

    private fun startAccess() {
        if (!Shizuku.pingBinder()) { status = "Inicia primeiro o Shizuku e ativa a depuração sem fios."; return }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) connectService()
        else Shizuku.requestPermission(permissionRequest)
    }

    private fun connectService() {
        try {
            val args = Shizuku.UserServiceArgs(ComponentName(packageName, SubtitleUserService::class.java.name))
                .daemon(false).processNameSuffix("subtitle").debuggable(false).version(1)
            Shizuku.bindUserService(args, connection)
            status = "A ligar ao serviço de ficheiros…"
        } catch (e: Exception) { status = "Não foi possível ligar: ${e.message ?: "erro desconhecido"}" }
    }

    private fun refresh() {
        val service = remote ?: return
        Thread {
            try {
                val result = service.findSubtitles(root)?.toList() ?: emptyList()
                runOnUiThread { subtitles = result; status = if (result.isEmpty()) "Não foram encontrados .srt. Confirma se o VLC já descarregou alguma legenda." else "${result.size} legenda(s) encontradas." }
            } catch (e: Exception) { runOnUiThread { status = "Erro ao pesquisar: ${e.message}" } }
        }.start()
    }

    private fun copy(path: String) {
        val service = remote ?: return
        Thread {
            val ok = try { service.copySubtitle(path, path.substringAfterLast('/')) } catch (_: Exception) { false }
            runOnUiThread { status = if (ok) "Legenda copiada para Downloads." else "Não foi possível copiar a legenda." }
        }.start()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        try {
            val args = Shizuku.UserServiceArgs(ComponentName(packageName, SubtitleUserService::class.java.name))
                .daemon(false).processNameSuffix("subtitle").debuggable(false).version(1)
            Shizuku.unbindUserService(args, connection, true)
        } catch (_: Exception) { }
        super.onDestroy()
    }
}
