package pt.joaomg.vlcsubtitle;

import android.os.RemoteException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;

/** Runs under Shizuku's shell identity. It only reads VLC's files and writes copies to Downloads. */
public final class SubtitleUserService extends ISubtitleService.Stub {
    private static final String VLC_ROOT = "/storage/emulated/0/Android/data/org.videolan.vlc/files";
    private static final String DOWNLOADS = "/storage/emulated/0/Download";

    @Override public String[] findSubtitles(String requestedRoot) throws RemoteException {
        if (!VLC_ROOT.equals(requestedRoot)) return new String[0];
        File root = new File(VLC_ROOT);
        if (!root.isDirectory()) return new String[0];
        ArrayList<String> found = new ArrayList<>();
        walk(root, found, 0);
        found.sort(String.CASE_INSENSITIVE_ORDER);
        return found.toArray(new String[0]);
    }

    private void walk(File dir, ArrayList<String> out, int depth) {
        if (depth > 12 || out.size() >= 3000) return;
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File f : children) {
            try {
                if (f.isDirectory()) walk(f, out, depth + 1);
                else if (f.isFile() && f.getName().toLowerCase().endsWith(".srt")) out.add(f.getCanonicalPath());
            } catch (IOException ignored) { }
        }
    }

    @Override public boolean copySubtitle(String sourcePath, String destinationName) throws RemoteException {
        try {
            File source = new File(sourcePath).getCanonicalFile();
            File allowedRoot = new File(VLC_ROOT).getCanonicalFile();
            if (!source.getPath().startsWith(allowedRoot.getPath() + File.separator) || !source.isFile() || !source.getName().toLowerCase().endsWith(".srt")) return false;
            String safeName = new File(destinationName).getName().replaceAll("[^\\p{L}\\p{N}._() -]", "_");
            if (!safeName.toLowerCase().endsWith(".srt")) safeName += ".srt";
            File targetDir = new File(DOWNLOADS);
            if (!targetDir.exists() && !targetDir.mkdirs()) return false;
            File target = new File(targetDir, safeName).getCanonicalFile();
            if (!target.getParent().equals(new File(DOWNLOADS).getCanonicalPath())) return false;
            try (FileInputStream in = new FileInputStream(source); FileOutputStream out = new FileOutputStream(target, false)) {
                byte[] buffer = new byte[32 * 1024]; int n;
                while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                out.getFD().sync();
            }
            return true;
        } catch (IOException | SecurityException e) { return false; }
    }
}
