package pt.joaomg.vlcsubtitle;

interface ISubtitleService {
    String[] findSubtitles(String rootPath);
    boolean copySubtitle(String sourcePath, String destinationName);
}
