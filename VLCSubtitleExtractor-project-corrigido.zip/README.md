# VLC Subtitle Extractor (protótipo Android)

Aplicação Android em português para procurar ficheiros `.srt` na pasta de ficheiros do VLC e copiar uma legenda escolhida para `Download`.

## Estado

Este é um **projeto-fonte inicial**, não um APK compilado nem uma versão validada num Samsung. O ambiente em que foi preparado não inclui Android SDK/Gradle, por isso não foi possível compilar nem testar a aplicação. A integração Shizuku e o acesso à pasta têm de ser validados no dispositivo antes de considerar a aplicação pronta.

## Requisitos

- Android 8.0 ou superior (configuração inicial: minSdk 26)
- VLC para Android
- Shizuku instalado e iniciado
- Android Studio recente e JDK 17 para compilar

## Compilar

1. Abrir esta pasta no Android Studio.
2. Permitir a sincronização do Gradle e instalar o Android SDK 35, se solicitado.
3. Executar `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Configurar o Shizuku no próprio Samsung

1. Instalar o Shizuku a partir do site oficial: https://shizuku.rikka.app/
2. Abrir Shizuku e escolher **Iniciar através da depuração sem fios**.
3. Ativar Opções de programador e Depuração sem fios.
4. Emparelhar com o código apresentado pelo Android e iniciar o serviço.
5. Abrir a aplicação e autorizar o acesso Shizuku quando solicitado.

O Shizuku iniciado por depuração sem fios tem de ser reiniciado após reiniciar o telemóvel.

## Limitações conhecidas / validação necessária

- O caminho esperado é `/storage/emulated/0/Android/data/org.videolan.vlc/files`.
- O protótipo procura apenas ficheiros `.srt` e percorre até 12 níveis de pastas.
- O acesso depende das permissões efetivas do UID shell no firmware/versão Android do equipamento. Shizuku não garante que todas as operações de ficheiros sejam permitidas em todas as versões.
- A cópia usa o nome original; se já existir um ficheiro com o mesmo nome em Downloads, será substituído.
- A aplicação ainda não foi compilada, instalada ou testada. É necessário corrigir eventuais incompatibilidades de API/Gradle e validar leitura/cópia no equipamento real.

## Privacidade

Não há rede, anúncios, telemetria nem envio de ficheiros. A aplicação só tenta ler a pasta VLC indicada e copiar o `.srt` escolhido para Downloads. Não apaga nem altera a origem.
